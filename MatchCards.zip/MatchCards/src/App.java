public class App {
    public static void main(String[] args) {
          new LoginSignupFrame(); 
        // new MatchCards2(); //

    }
}
